"""Reconnaissance modules for waymap."""
