Format: 3.0 (native)
Source: waymap
Binary: waymap
Architecture: all
Version: 8.2.0-1
Maintainer: Trix Cyrus <trixsec@proton.me>
Homepage: https://github.com/TrixSec/waymap
Standards-Version: 4.6.2
Vcs-Browser: https://github.com/TrixSec/waymap
Vcs-Git: https://github.com/TrixSec/waymap.git
Build-Depends: debhelper-compat (= 13), python3-all, python3-setuptools, dh-python
Package-List:
 waymap deb net optional arch=all
Checksums-Sha1:
 ba853d88210f00f045a7dc0ed3da9d7e65cf668e 1436324 waymap_8.2.0-1.tar.xz
Checksums-Sha256:
 4046ef42e17de422bf148e24d080cac004f445a8fdaae9306959d22e08d7a1be 1436324 waymap_8.2.0-1.tar.xz
Files:
 7d4b15e0d8f53f82bbe92fb3cea840a4 1436324 waymap_8.2.0-1.tar.xz
