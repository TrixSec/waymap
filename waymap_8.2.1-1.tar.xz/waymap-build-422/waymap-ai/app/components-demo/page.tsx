'use client'

import React, { useState } from 'react'
import { AppLayout } from '@/components/AppLayout'
import { Card } from '@/components/Card'
import { Dropdown, SelectDropdown } from '@/components/Dropdown'
import { Scroller, CustomScroll, VirtualScrollList } from '@/components/Scroller'
import {
  Settings,
  LogOut,
  Download,
  Share2,
  Trash2,
  Edit2,
  Eye,
  AlertCircle,
  CheckCircle2,
  Shield,
  BarChart3,
} from 'lucide-react'

export default function ComponentsDemo() {
  const [selectedSeverity, setSelectedSeverity] = useState<string>('')
  const [selectedReport, setSelectedReport] = useState<string>('')

  const severityOptions = [
    { id: 'critical', label: 'Critical', icon: <AlertCircle size={16} className="text-critical" /> },
    { id: 'high', label: 'High', icon: <AlertCircle size={16} className="text-high" /> },
    { id: 'medium', label: 'Medium', icon: <AlertCircle size={16} className="text-medium" /> },
    { id: 'low', label: 'Low', icon: <AlertCircle size={16} className="text-low" /> },
  ]

  const reportOptions = [
    { id: 'full', label: 'Full Scan Report' },
    { id: 'executive', label: 'Executive Summary' },
    { id: 'compliance', label: 'Compliance Report' },
    { id: 'vulnerability', label: 'Vulnerability Details' },
    { id: 'remediation', label: 'Remediation Guide' },
  ]

  const dropdownItems = [
    { id: 'view', label: 'View Details', icon: <Eye size={16} /> },
    { id: 'edit', label: 'Edit', icon: <Edit2 size={16} /> },
    { id: 'download', label: 'Download', icon: <Download size={16} /> },
    { id: 'share', label: 'Share', icon: <Share2 size={16} /> },
    { id: 'divider1', label: '', divider: true },
    { id: 'delete', label: 'Delete', icon: <Trash2 size={16} className="text-critical" /> },
  ]

  const horizontalCards = [
    { id: 1, title: 'Web Applications', icon: Globe },
    { id: 2, title: 'API Endpoints', icon: Shield },
    { id: 3, title: 'Mobile Apps', icon: BarChart3 },
    { id: 4, title: 'Cloud Services', icon: Settings },
    { id: 5, title: 'Containers', icon: CheckCircle2 },
    { id: 6, title: 'Infrastructure', icon: Download },
    { id: 7, title: 'Databases', icon: Share2 },
  ]

  const mockItems = Array.from({ length: 50 }, (_, i) => ({
    id: i,
    title: `Item ${i + 1}`,
    severity: severityOptions[i % severityOptions.length],
  }))

  return (
    <AppLayout>
      <div className="space-y-8 p-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Component Library</h1>
          <p className="text-muted-foreground">
            Custom dropdowns, menus, and scrollers with Waymap design system
          </p>
        </div>

        {/* Dropdown Menu Demo */}
        <Card>
          <div className="p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Dropdown Menu</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Trigger-based dropdown menu with icons, dividers, and disabled states
            </p>

            <div className="flex gap-4">
              <Dropdown
                trigger={<>Actions</>}
                items={dropdownItems.map((item) => ({
                  ...item,
                  onClick: () => console.log(`Clicked: ${item.label}`),
                }))}
              />

              <Dropdown
                trigger={<>More Options</>}
                items={dropdownItems}
                align="right"
                triggerClassName="bg-accent text-accent-foreground hover:bg-primary"
              />

              <Dropdown
                trigger={<Settings size={20} />}
                items={[
                  { id: 'settings', label: 'Settings', icon: <Settings size={16} /> },
                  { id: 'logout', label: 'Logout', icon: <LogOut size={16} /> },
                ]}
              />
            </div>
          </div>
        </Card>

        {/* Select Dropdown Demo */}
        <Card>
          <div className="p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Select Dropdown</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Searchable select component with icons and custom styling
            </p>

            <div className="grid grid-cols-2 gap-6">
              <SelectDropdown
                label="Filter by Severity"
                options={severityOptions}
                selected={selectedSeverity}
                onSelect={setSelectedSeverity}
                placeholder="Choose severity level"
              />

              <SelectDropdown
                label="Report Type"
                options={reportOptions}
                selected={selectedReport}
                onSelect={setSelectedReport}
                placeholder="Select report type"
              />
            </div>

            {selectedSeverity && (
              <p className="mt-4 text-sm text-muted-foreground">
                Selected: <span className="text-foreground font-medium">{selectedSeverity}</span>
              </p>
            )}
          </div>
        </Card>

        {/* Horizontal Scroller Demo */}
        <Card>
          <div className="p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Horizontal Scroller</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Smooth scrolling with auto-showing navigation buttons on hover
            </p>

            <Scroller showScrollButtons orientation="horizontal">
              {horizontalCards.map((card) => (
                <div
                  key={card.id}
                  className="flex-shrink-0 w-48 bg-secondary border border-border rounded-lg p-4 hover:bg-accent transition-colors cursor-pointer"
                >
                  <div className="h-12 w-12 bg-primary rounded-lg flex items-center justify-center mb-3">
                    <card.icon size={24} className="text-primary-foreground" />
                  </div>
                  <h3 className="font-semibold text-foreground">{card.title}</h3>
                  <p className="text-xs text-muted-foreground mt-2">Scan & monitor</p>
                </div>
              ))}
            </Scroller>
          </div>
        </Card>

        {/* Custom Scrollbar Demo */}
        <Card>
          <div className="p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Custom Scrollbar</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Styled scrollbar that matches the Waymap design system
            </p>

            <CustomScroll className="h-64 border border-border rounded-lg p-4 bg-input">
              <div className="space-y-3">
                {Array.from({ length: 20 }).map((_, i) => (
                  <div
                    key={i}
                    className="p-3 bg-card border border-border rounded-lg hover:bg-secondary transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center text-xs font-semibold text-accent-foreground">
                        {i + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">
                          Vulnerability {i + 1}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">
                          www.example.com/path/{i}
                        </p>
                      </div>
                      <div className="flex-shrink-0">
                        <span className="px-2 py-1 text-xs font-medium rounded-lg bg-critical bg-opacity-10 text-critical">
                          {severityOptions[i % 4].label}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CustomScroll>
          </div>
        </Card>

        {/* Virtual Scroll List Demo */}
        <Card>
          <div className="p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Virtual Scroll List</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Performance-optimized list rendering for large datasets (50 items)
            </p>

            <VirtualScrollList
              items={mockItems}
              itemHeight={56}
              containerHeight={400}
              renderItem={(item, index) => (
                <div className="p-3 border-b border-border hover:bg-secondary transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center text-xs font-semibold text-accent-foreground">
                      {index + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground">{item.title}</p>
                      <p className="text-xs text-muted-foreground">
                        Scan ID: {`WMS-${String(index + 1).padStart(5, '0')}`}
                      </p>
                    </div>
                    <span className={`px-2 py-1 text-xs font-medium rounded-lg ${
                      item.severity.id === 'critical'
                        ? 'bg-critical bg-opacity-10 text-critical'
                        : item.severity.id === 'high'
                          ? 'bg-high bg-opacity-10 text-high'
                          : item.severity.id === 'medium'
                            ? 'bg-medium bg-opacity-10 text-medium'
                            : 'bg-low bg-opacity-10 text-low'
                    }`}>
                      {item.severity.label}
                    </span>
                  </div>
                </div>
              )}
            />
          </div>
        </Card>

        {/* Integrated Example */}
        <Card>
          <div className="p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Integrated Example</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Combining dropdowns and scrollers in a realistic scanning interface
            </p>

            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <SelectDropdown
                  label="Project"
                  options={[
                    { id: 'proj1', label: 'E-commerce Platform' },
                    { id: 'proj2', label: 'Mobile App API' },
                    { id: 'proj3', label: 'Admin Dashboard' },
                  ]}
                  selected={selectedReport}
                  onSelect={setSelectedReport}
                  className="flex-1"
                />

                <div className="pt-6">
                  <Dropdown
                    trigger={<>Export</>}
                    items={[
                      { id: 'pdf', label: 'PDF Report', icon: <Download size={16} /> },
                      { id: 'csv', label: 'CSV Data', icon: <Download size={16} /> },
                      { id: 'json', label: 'JSON Format', icon: <Download size={16} /> },
                    ]}
                  />
                </div>
              </div>

              <CustomScroll className="h-48 border border-border rounded-lg p-4 bg-input">
                <div className="space-y-2">
                  {Array.from({ length: 12 }).map((_, i) => (
                    <div
                      key={i}
                      className="p-2 bg-card border border-border rounded hover:bg-secondary transition-colors flex items-center gap-3 text-sm"
                    >
                      <div className="w-2 h-2 rounded-full bg-critical flex-shrink-0" />
                      <span className="text-foreground truncate">Unrestricted file upload in /admin/upload</span>
                      <span className="text-xs text-muted-foreground flex-shrink-0">Critical</span>
                    </div>
                  ))}
                </div>
              </CustomScroll>
            </div>
          </div>
        </Card>
      </div>
    </AppLayout>
  )
}

// Icon component references
function Globe(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} {...props}>
      <circle cx="12" cy="12" r="10" />
      <path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
    </svg>
  )
}
