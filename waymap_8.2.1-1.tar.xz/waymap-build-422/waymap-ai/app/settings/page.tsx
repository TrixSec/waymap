'use client'

import { useState } from 'react'
import { AppLayout } from '@/components/AppLayout'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card'
import { WaymapButton } from '@/components/WaymapButton'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/Tabs'
import { Bell, Lock, Palette, Shield, User, Zap } from 'lucide-react'

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('general')

  return (
    <AppLayout title="Settings" subtitle="Manage your account and application settings">
      <div className="max-w-4xl space-y-6">
        {/* Tabs */}
        <Card>
          <CardContent className="p-0">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-5 gap-0 border-b border-border">
                <TabsTrigger value="general">
                  <User className="w-4 h-4 mr-2" />
                  General
                </TabsTrigger>
                <TabsTrigger value="security">
                  <Lock className="w-4 h-4 mr-2" />
                  Security
                </TabsTrigger>
                <TabsTrigger value="notifications">
                  <Bell className="w-4 h-4 mr-2" />
                  Notifications
                </TabsTrigger>
                <TabsTrigger value="integrations">
                  <Zap className="w-4 h-4 mr-2" />
                  Integrations
                </TabsTrigger>
                <TabsTrigger value="billing">
                  <Shield className="w-4 h-4 mr-2" />
                  Billing
                </TabsTrigger>
              </TabsList>

              {/* General Settings */}
              <TabsContent value="general" className="p-6 space-y-6">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Organization Name
                  </label>
                  <input
                    type="text"
                    defaultValue="Acme Corporation"
                    className="w-full px-4 py-2 border border-border rounded-lg bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    defaultValue="john@example.com"
                    className="w-full px-4 py-2 border border-border rounded-lg bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    defaultValue="+1 (555) 123-4567"
                    className="w-full px-4 py-2 border border-border rounded-lg bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <WaymapButton variant="primary">Save Changes</WaymapButton>
              </TabsContent>

              {/* Security Settings */}
              <TabsContent value="security" className="p-6 space-y-6">
                <div>
                  <h4 className="font-semibold text-foreground mb-4">Password</h4>
                  <WaymapButton variant="outline">Change Password</WaymapButton>
                </div>

                <div className="border-t border-border pt-6">
                  <h4 className="font-semibold text-foreground mb-4">Two-Factor Authentication</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    Add an extra layer of security to your account
                  </p>
                  <WaymapButton variant="outline">Enable 2FA</WaymapButton>
                </div>

                <div className="border-t border-border pt-6">
                  <h4 className="font-semibold text-foreground mb-4">Active Sessions</h4>
                  <div className="space-y-2">
                    {[
                      { device: 'Chrome on macOS', location: 'New York, USA', time: '2 hours ago' },
                      { device: 'Safari on iPhone', location: 'New York, USA', time: '1 day ago' },
                    ].map((session, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                        <div>
                          <p className="font-medium text-foreground">{session.device}</p>
                          <p className="text-sm text-muted-foreground">
                            {session.location} • {session.time}
                          </p>
                        </div>
                        <WaymapButton variant="outline" size="sm">
                          Logout
                        </WaymapButton>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              {/* Notifications */}
              <TabsContent value="notifications" className="p-6 space-y-6">
                <div className="space-y-4">
                  {[
                    {
                      title: 'Critical Vulnerabilities',
                      desc: 'Alert when critical vulnerabilities are detected',
                    },
                    {
                      title: 'Scan Completion',
                      desc: 'Notify when scans complete successfully',
                    },
                    {
                      title: 'Weekly Report',
                      desc: 'Receive weekly security summaries',
                    },
                    {
                      title: 'Team Updates',
                      desc: 'Get notified of team member activities',
                    },
                  ].map((notif, idx) => (
                    <label key={idx} className="flex items-start gap-3 p-3 bg-secondary rounded-lg">
                      <input type="checkbox" defaultChecked className="mt-1" />
                      <div>
                        <p className="font-medium text-foreground">{notif.title}</p>
                        <p className="text-sm text-muted-foreground">{notif.desc}</p>
                      </div>
                    </label>
                  ))}
                </div>
                <WaymapButton variant="primary">Save Preferences</WaymapButton>
              </TabsContent>

              {/* Integrations */}
              <TabsContent value="integrations" className="p-6 space-y-6">
                <div className="space-y-4">
                  {[
                    { name: 'Slack', status: 'connected', color: 'bg-blue-100' },
                    { name: 'GitHub', status: 'not-connected', color: 'bg-gray-100' },
                    { name: 'Jira', status: 'not-connected', color: 'bg-blue-100' },
                    { name: 'PagerDuty', status: 'connected', color: 'bg-green-100' },
                  ].map((integration, idx) => (
                    <div
                      key={idx}
                      className={`flex items-center justify-between p-4 rounded-lg border border-border ${integration.color}`}
                    >
                      <div>
                        <p className="font-medium text-foreground">{integration.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {integration.status === 'connected' ? 'Connected' : 'Not connected'}
                        </p>
                      </div>
                      <WaymapButton
                        variant={integration.status === 'connected' ? 'outline' : 'primary'}
                        size="sm"
                      >
                        {integration.status === 'connected' ? 'Disconnect' : 'Connect'}
                      </WaymapButton>
                    </div>
                  ))}
                </div>
              </TabsContent>

              {/* Billing */}
              <TabsContent value="billing" className="p-6 space-y-6">
                <div className="p-4 bg-secondary rounded-lg">
                  <p className="text-sm text-muted-foreground mb-2">Current Plan</p>
                  <p className="text-2xl font-bold text-foreground mb-4">Professional</p>
                  <p className="text-sm text-muted-foreground">
                    $99/month • Renews on February 15, 2024
                  </p>
                </div>

                <div className="border-t border-border pt-6">
                  <h4 className="font-semibold text-foreground mb-4">Billing History</h4>
                  <div className="space-y-2">
                    {[
                      { date: 'January 15, 2024', amount: '$99.00', status: 'Paid' },
                      { date: 'December 15, 2023', amount: '$99.00', status: 'Paid' },
                      { date: 'November 15, 2023', amount: '$99.00', status: 'Paid' },
                    ].map((invoice, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                        <div>
                          <p className="font-medium text-foreground">{invoice.date}</p>
                          <p className="text-sm text-muted-foreground">{invoice.status}</p>
                        </div>
                        <p className="font-semibold text-foreground">{invoice.amount}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  )
}
