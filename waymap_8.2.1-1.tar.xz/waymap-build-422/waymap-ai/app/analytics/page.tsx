import { AppLayout } from '@/components/AppLayout'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card'
import { BarChart3, TrendingUp, Calendar } from 'lucide-react'

export default function AnalyticsPage() {
  return (
    <AppLayout
      title="Analytics"
      subtitle="View your security metrics and trends over time"
    >
      <div className="space-y-6">
        {/* Date Range Selector */}
        <Card>
          <CardContent className="flex items-center gap-4">
            <Calendar className="w-5 h-5 text-muted-foreground" />
            <select className="px-4 py-2 border border-border rounded-lg bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary">
              <option>Last 7 days</option>
              <option>Last 30 days</option>
              <option>Last 90 days</option>
              <option>Last year</option>
            </select>
          </CardContent>
        </Card>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <div>
              <p className="text-sm text-muted-foreground mb-2">Total Scans</p>
              <p className="text-3xl font-bold text-foreground">247</p>
              <p className="text-xs text-low mt-2">+12% from last month</p>
            </div>
          </Card>
          <Card>
            <div>
              <p className="text-sm text-muted-foreground mb-2">Avg Vulnerabilities/Scan</p>
              <p className="text-3xl font-bold text-foreground">34</p>
              <p className="text-xs text-high mt-2">-8% from last month</p>
            </div>
          </Card>
          <Card>
            <div>
              <p className="text-sm text-muted-foreground mb-2">Remediation Rate</p>
              <p className="text-3xl font-bold text-foreground">68%</p>
              <p className="text-xs text-low mt-2">+5% from last month</p>
            </div>
          </Card>
          <Card>
            <div>
              <p className="text-sm text-muted-foreground mb-2">Avg Response Time</p>
              <p className="text-3xl font-bold text-foreground">2.4 days</p>
              <p className="text-xs text-medium mt-2">-0.8 days from last month</p>
            </div>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Vulnerability Trend */}
          <Card>
            <CardHeader>
              <CardTitle>Vulnerability Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center bg-secondary rounded-lg">
                <div className="text-center">
                  <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">Chart visualization would appear here</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Severity Distribution */}
          <Card>
            <CardHeader>
              <CardTitle>Severity Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { label: 'Critical', value: 12, color: 'bg-critical', percent: 5 },
                  { label: 'High', value: 34, color: 'bg-high', percent: 14 },
                  { label: 'Medium', value: 87, color: 'bg-medium', percent: 35 },
                  { label: 'Low', value: 114, color: 'bg-low', percent: 46 },
                ].map((item) => (
                  <div key={item.label}>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-foreground">{item.label}</span>
                      <span className="text-sm text-muted-foreground">
                        {item.value} ({item.percent}%)
                      </span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${item.color}`}
                        style={{ width: `${item.percent}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Vulnerabilities */}
          <Card>
            <CardHeader>
              <CardTitle>Top Vulnerabilities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { name: 'SQL Injection', count: 47 },
                  { name: 'XSS Vulnerabilities', count: 38 },
                  { name: 'Missing Headers', count: 29 },
                  { name: 'Weak Auth', count: 24 },
                  { name: 'CORS Issues', count: 18 },
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <span className="text-sm text-foreground">{item.name}</span>
                    <span className="text-sm font-semibold text-primary">{item.count}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Team Performance */}
          <Card>
            <CardHeader>
              <CardTitle>Team Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { name: 'Security Team', remediated: 28, time: '2.1 days' },
                  { name: 'Dev Team', remediated: 15, time: '3.8 days' },
                  { name: 'Ops Team', remediated: 12, time: '2.9 days' },
                  { name: 'DevOps Team', remediated: 18, time: '1.5 days' },
                ].map((team, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">{team.name}</p>
                      <p className="text-xs text-muted-foreground">{team.time} avg response</p>
                    </div>
                    <span className="text-sm font-semibold text-primary">{team.remediated} issues</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  )
}
