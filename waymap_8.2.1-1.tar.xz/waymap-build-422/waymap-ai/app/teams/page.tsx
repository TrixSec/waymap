import { AppLayout } from '@/components/AppLayout'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card'
import { WaymapButton } from '@/components/WaymapButton'
import { Badge } from '@/components/Badge'
import { Table, TableHeader, TableBody, TableRow, TableCell } from '@/components/Table'
import { Users, Plus, Mail, Trash2, Edit2, Shield } from 'lucide-react'

const teamMembers = [
  {
    id: 1,
    name: 'John Doe',
    email: 'john@example.com',
    role: 'Admin',
    status: 'active',
  },
  {
    id: 2,
    name: 'Jane Smith',
    email: 'jane@example.com',
    role: 'Security Lead',
    status: 'active',
  },
  {
    id: 3,
    name: 'Bob Johnson',
    email: 'bob@example.com',
    role: 'Developer',
    status: 'active',
  },
  {
    id: 4,
    name: 'Alice Williams',
    email: 'alice@example.com',
    role: 'Analyst',
    status: 'pending',
  },
]

export default function TeamsPage() {
  return (
    <AppLayout title="Teams" subtitle="Manage your organization and team members">
      <div className="space-y-6">
        {/* Add Member */}
        <Card>
          <CardContent className="flex items-center gap-4">
            <Users className="w-5 h-5 text-muted-foreground" />
            <input
              type="email"
              placeholder="Enter email to invite team member"
              className="flex-1 px-4 py-2 border border-border rounded-lg bg-input text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <WaymapButton variant="primary" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Invite
            </WaymapButton>
          </CardContent>
        </Card>

        {/* Team Members */}
        <Card>
          <CardHeader>
            <CardTitle>Team Members</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableCell header>Name</TableCell>
                <TableCell header>Email</TableCell>
                <TableCell header>Role</TableCell>
                <TableCell header>Status</TableCell>
                <TableCell header>Actions</TableCell>
              </TableHeader>
              <TableBody>
                {teamMembers.map((member) => (
                  <TableRow key={member.id}>
                    <TableCell className="font-semibold">{member.name}</TableCell>
                    <TableCell className="text-sm">{member.email}</TableCell>
                    <TableCell>
                      <select className="px-2 py-1 border border-border rounded bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary">
                        <option>Admin</option>
                        <option>Security Lead</option>
                        <option>Developer</option>
                        <option>Analyst</option>
                        <option>Viewer</option>
                      </select>
                    </TableCell>
                    <TableCell>
                      <Badge severity={member.status === 'active' ? 'low' : 'info'}>
                        {member.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <button className="p-1.5 hover:bg-accent rounded transition-colors">
                          <Edit2 className="w-4 h-4 text-muted-foreground" />
                        </button>
                        <button className="p-1.5 hover:bg-accent rounded transition-colors">
                          <Trash2 className="w-4 h-4 text-muted-foreground" />
                        </button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Roles & Permissions */}
        <div>
          <h3 className="text-lg font-semibold text-foreground mb-4">Roles & Permissions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              {
                role: 'Admin',
                permissions: [
                  'Full access to all features',
                  'Manage team members',
                  'Configure settings',
                  'Generate reports',
                ],
              },
              {
                role: 'Security Lead',
                permissions: [
                  'View all scans and vulnerabilities',
                  'Create and manage reports',
                  'Configure scan policies',
                  'Cannot manage team members',
                ],
              },
            ].map((roleData, idx) => (
              <Card key={idx}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    {roleData.role}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {roleData.permissions.map((perm, pidx) => (
                      <li key={pidx} className="flex items-start gap-2 text-sm text-foreground">
                        <span className="text-primary mt-1">✓</span>
                        {perm}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Pending Invitations */}
        <Card>
          <CardHeader>
            <CardTitle>Pending Invitations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { email: 'new-member@example.com', sentDate: '2024-01-20' },
                { email: 'another@example.com', sentDate: '2024-01-18' },
              ].map((invitation, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 bg-secondary rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-muted-foreground" />
                    <div>
                      <p className="font-medium text-foreground">{invitation.email}</p>
                      <p className="text-sm text-muted-foreground">Sent {invitation.sentDate}</p>
                    </div>
                  </div>
                  <WaymapButton variant="outline" size="sm">
                    Resend
                  </WaymapButton>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  )
}
