import { AppLayout } from '@/components/AppLayout'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card'
import { WaymapButton } from '@/components/WaymapButton'
import { Badge } from '@/components/Badge'
import { Table, TableHeader, TableBody, TableRow, TableCell } from '@/components/Table'
import { FileText, Download, Share2, Eye } from 'lucide-react'

const reports = [
  {
    id: 1,
    name: 'Monthly Security Report - January 2024',
    generatedDate: '2024-01-31',
    target: 'Production Environment',
    vulnerabilities: 247,
    status: 'completed',
  },
  {
    id: 2,
    name: 'API Security Assessment',
    generatedDate: '2024-01-28',
    target: 'api.example.com',
    vulnerabilities: 12,
    status: 'completed',
  },
  {
    id: 3,
    name: 'Infrastructure Audit Report',
    generatedDate: '2024-01-25',
    target: 'Internal Network',
    vulnerabilities: 34,
    status: 'completed',
  },
  {
    id: 4,
    name: 'Compliance Check - OWASP Top 10',
    generatedDate: '2024-01-20',
    target: 'Web Application',
    vulnerabilities: 8,
    status: 'completed',
  },
  {
    id: 5,
    name: 'Quarterly Compliance Report',
    generatedDate: '2024-01-15',
    target: 'Full Stack',
    vulnerabilities: 156,
    status: 'completed',
  },
]

export default function ReportsPage() {
  return (
    <AppLayout title="Reports" subtitle="View and manage your security reports">
      <div className="space-y-6">
        {/* Actions */}
        <div className="flex gap-4">
          <WaymapButton variant="primary">
            <FileText className="w-4 h-4 mr-2" />
            Generate Report
          </WaymapButton>
          <WaymapButton variant="outline">
            <Share2 className="w-4 h-4 mr-2" />
            Schedule Reports
          </WaymapButton>
        </div>

        {/* Reports Table */}
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableCell header>Report Name</TableCell>
                <TableCell header>Target</TableCell>
                <TableCell header>Vulnerabilities</TableCell>
                <TableCell header>Generated</TableCell>
                <TableCell header>Actions</TableCell>
              </TableHeader>
              <TableBody>
                {reports.map((report) => (
                  <TableRow key={report.id}>
                    <TableCell className="font-semibold">{report.name}</TableCell>
                    <TableCell>{report.target}</TableCell>
                    <TableCell>
                      <Badge severity={report.vulnerabilities > 100 ? 'high' : 'medium'}>
                        {report.vulnerabilities} issues
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {report.generatedDate}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <button className="p-1.5 hover:bg-accent rounded transition-colors">
                          <Eye className="w-4 h-4 text-muted-foreground" />
                        </button>
                        <button className="p-1.5 hover:bg-accent rounded transition-colors">
                          <Download className="w-4 h-4 text-muted-foreground" />
                        </button>
                        <button className="p-1.5 hover:bg-accent rounded transition-colors">
                          <Share2 className="w-4 h-4 text-muted-foreground" />
                        </button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Report Templates */}
        <div>
          <h3 className="text-lg font-semibold text-foreground mb-4">Report Templates</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { name: 'Executive Summary', desc: 'High-level overview for executives' },
              { name: 'Technical Findings', desc: 'Detailed technical analysis' },
              { name: 'Compliance Report', desc: 'Compliance-focused findings' },
            ].map((template, idx) => (
              <Card key={idx} className="cursor-pointer hover:border-primary transition-colors">
                <CardContent className="flex flex-col items-center text-center py-6">
                  <FileText className="w-8 h-8 text-primary mb-2" />
                  <h4 className="font-semibold text-foreground mb-1">{template.name}</h4>
                  <p className="text-sm text-muted-foreground mb-4">{template.desc}</p>
                  <WaymapButton variant="outline" size="sm">
                    Use Template
                  </WaymapButton>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  )
}
