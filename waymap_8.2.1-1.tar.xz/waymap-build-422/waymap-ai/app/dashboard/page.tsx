import { AppLayout } from '@/components/AppLayout'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card'
import { Badge } from '@/components/Badge'
import { WaymapButton } from '@/components/WaymapButton'
import {
  BarChart3,
  Shield,
  AlertTriangle,
  TrendingUp,
  CheckCircle2,
  Clock,
} from 'lucide-react'
import { Table, TableHeader, TableBody, TableRow, TableCell } from '@/components/Table'

export default function DashboardPage() {
  return (
    <AppLayout title="Dashboard" subtitle="Welcome back! Here's your security overview.">
      <div className="space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Vulnerabilities</p>
                <p className="text-3xl font-bold text-foreground">247</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-high" />
            </div>
          </Card>

          <Card>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Critical Issues</p>
                <p className="text-3xl font-bold text-critical">12</p>
              </div>
              <Shield className="w-8 h-8 text-critical" />
            </div>
          </Card>

          <Card>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Last Scan</p>
                <p className="text-lg font-semibold text-foreground">2 hours ago</p>
              </div>
              <Clock className="w-8 h-8 text-info" />
            </div>
          </Card>

          <Card>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Security Score</p>
                <p className="text-3xl font-bold text-low">78/100</p>
              </div>
              <TrendingUp className="w-8 h-8 text-low" />
            </div>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <WaymapButton variant="primary" className="w-full">
                <Shield className="w-4 h-4 mr-2" />
                Start New Scan
              </WaymapButton>
              <WaymapButton variant="outline" className="w-full">
                <FileText className="w-4 h-4 mr-2" />
                View Reports
              </WaymapButton>
              <WaymapButton variant="outline" className="w-full">
                <BarChart3 className="w-4 h-4 mr-2" />
                Analytics
              </WaymapButton>
            </div>
          </CardContent>
        </Card>

        {/* Recent Vulnerabilities */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Vulnerabilities</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableCell header>Vulnerability</TableCell>
                <TableCell header>Severity</TableCell>
                <TableCell header>Affected Items</TableCell>
                <TableCell header>Status</TableCell>
              </TableHeader>
              <TableBody>
                {[
                  {
                    name: 'SQL Injection in Login Form',
                    severity: 'critical',
                    items: 3,
                    status: 'Open',
                  },
                  {
                    name: 'Missing Security Headers',
                    severity: 'high',
                    items: 8,
                    status: 'In Review',
                  },
                  {
                    name: 'Outdated Dependencies',
                    severity: 'medium',
                    items: 15,
                    status: 'Open',
                  },
                  {
                    name: 'Weak Password Policy',
                    severity: 'high',
                    items: 124,
                    status: 'Open',
                  },
                  {
                    name: 'CORS Misconfiguration',
                    severity: 'low',
                    items: 2,
                    status: 'Resolved',
                  },
                ].map((item, idx) => (
                  <TableRow key={idx}>
                    <TableCell>{item.name}</TableCell>
                    <TableCell>
                      <Badge severity={item.severity as any}>{item.severity}</Badge>
                    </TableCell>
                    <TableCell>{item.items}</TableCell>
                    <TableCell>
                      <span
                        className={`text-sm font-medium px-2 py-1 rounded ${
                          item.status === 'Resolved'
                            ? 'bg-green-100 text-green-900'
                            : item.status === 'In Review'
                              ? 'bg-blue-100 text-blue-900'
                              : 'bg-red-100 text-red-900'
                        }`}
                      >
                        {item.status}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  )
}

// Add missing imports
import { FileText } from 'lucide-react'
