import { AppLayout } from '@/components/AppLayout'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card'
import { Badge } from '@/components/Badge'
import { WaymapButton } from '@/components/WaymapButton'
import { CheckCircle2, AlertCircle, Clock, Shield } from 'lucide-react'

const complianceFrameworks = [
  {
    name: 'OWASP Top 10',
    status: 'at-risk',
    compliance: 78,
    issues: 8,
    criticalItems: [
      'A01:2021 – Broken Access Control',
      'A03:2021 – Injection',
      'A07:2021 – Identification and Authentication Failures',
    ],
  },
  {
    name: 'CIS Controls',
    status: 'compliant',
    compliance: 92,
    issues: 2,
    criticalItems: [
      'Defense in Depth',
      'Secure Configuration Management',
    ],
  },
  {
    name: 'PCI-DSS',
    status: 'at-risk',
    compliance: 85,
    issues: 4,
    criticalItems: [
      'Requirement 2: Default Security Parameters',
      'Requirement 6: Security Vulnerabilities',
    ],
  },
  {
    name: 'ISO 27001',
    status: 'at-risk',
    compliance: 88,
    issues: 3,
    criticalItems: [
      'A.13.1 Network Security',
      'A.14.2 System Development',
    ],
  },
]

export default function CompliancePage() {
  return (
    <AppLayout
      title="Compliance & Frameworks"
      subtitle="Track compliance status across multiple security frameworks"
    >
      <div className="space-y-6">
        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Avg Compliance</p>
              <p className="text-3xl font-bold text-foreground">85.75%</p>
              <p className="text-xs text-low mt-2">+2% this month</p>
            </div>
          </Card>
          <Card>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Frameworks</p>
              <p className="text-3xl font-bold text-foreground">4</p>
              <p className="text-xs text-muted-foreground mt-2">All active</p>
            </div>
          </Card>
          <Card>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Total Issues</p>
              <p className="text-3xl font-bold text-critical">17</p>
              <p className="text-xs text-critical mt-2">-5% from last month</p>
            </div>
          </Card>
          <Card>
            <div>
              <p className="text-sm text-muted-foreground mb-1">At Risk</p>
              <p className="text-3xl font-bold text-high">3</p>
              <p className="text-xs text-muted-foreground mt-2">frameworks</p>
            </div>
          </Card>
        </div>

        {/* Frameworks */}
        <div className="space-y-4">
          {complianceFrameworks.map((framework) => {
            const statusConfig =
              framework.status === 'compliant'
                ? { bg: 'bg-green-50', border: 'border-green-200', icon: CheckCircle2, color: 'text-low' }
                : { bg: 'bg-orange-50', border: 'border-orange-200', icon: AlertCircle, color: 'text-high' }

            const StatusIcon = statusConfig.icon

            return (
              <Card key={framework.name} className={`${statusConfig.bg} border-2 ${statusConfig.border}`}>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start gap-4">
                      <StatusIcon className={`w-6 h-6 ${statusConfig.color} flex-shrink-0 mt-1`} />
                      <div>
                        <h3 className="text-lg font-semibold text-foreground">{framework.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          {framework.issues} open issue{framework.issues !== 1 ? 's' : ''}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge
                        severity={framework.status === 'compliant' ? 'low' : 'high'}
                        className="mb-2"
                      >
                        {framework.status === 'compliant' ? 'Compliant' : 'At Risk'}
                      </Badge>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mb-4">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-foreground">Compliance Score</span>
                      <span className="text-sm font-semibold text-foreground">{framework.compliance}%</span>
                    </div>
                    <div className="w-full bg-white/50 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full transition-all ${
                          framework.status === 'compliant'
                            ? 'bg-low'
                            : 'bg-high'
                        }`}
                        style={{ width: `${framework.compliance}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Critical Items */}
                  <div className="mb-4 pt-4 border-t border-current/20">
                    <p className="text-sm font-semibold text-foreground mb-2">Key Areas</p>
                    <div className="space-y-1">
                      {framework.criticalItems.map((item, idx) => (
                        <p key={idx} className="text-sm text-foreground">
                          • {item}
                        </p>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-4 border-t border-current/20">
                    <WaymapButton variant="outline" size="sm" className="flex-1">
                      View Details
                    </WaymapButton>
                    <WaymapButton variant="outline" size="sm" className="flex-1">
                      Generate Report
                    </WaymapButton>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Compliance Timeline */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Upcoming Audits & Deadlines
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                {
                  framework: 'ISO 27001 Audit',
                  date: 'March 15, 2024',
                  daysLeft: 45,
                  status: 'scheduled',
                },
                {
                  framework: 'PCI-DSS Recertification',
                  date: 'April 30, 2024',
                  daysLeft: 91,
                  status: 'scheduled',
                },
                {
                  framework: 'OWASP Top 10 Review',
                  date: 'February 28, 2024',
                  daysLeft: 21,
                  status: 'upcoming',
                },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 bg-secondary rounded-lg"
                >
                  <div>
                    <p className="font-medium text-foreground">{item.framework}</p>
                    <p className="text-sm text-muted-foreground">{item.date}</p>
                  </div>
                  <div className="text-right">
                    <Badge severity={item.daysLeft < 30 ? 'high' : 'info'}>
                      {item.daysLeft} days
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  )
}
