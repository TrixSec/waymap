'use client'

import { useState } from 'react'
import { AppLayout } from '@/components/AppLayout'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card'
import { Badge } from '@/components/Badge'
import { Table, TableHeader, TableBody, TableRow, TableCell } from '@/components/Table'
import { WaymapButton } from '@/components/WaymapButton'
import { SelectDropdown, Dropdown } from '@/components/Dropdown'
import { CustomScroll } from '@/components/Scroller'
import { ChevronDown, Filter, Download, Eye, Share2 } from 'lucide-react'

const vulnerabilities = [
  {
    id: 1,
    name: 'SQL Injection in Login Form',
    severity: 'critical',
    cvss: 9.8,
    cveBased: 'CVE-2024-1234',
    affectedServices: 3,
    discoveredDate: '2024-01-15',
    lastScanned: '2 hours ago',
  },
  {
    id: 2,
    name: 'Missing Security Headers (X-Frame-Options)',
    severity: 'high',
    cvss: 7.5,
    cveBased: 'CWE-693',
    affectedServices: 8,
    discoveredDate: '2024-01-10',
    lastScanned: '2 hours ago',
  },
  {
    id: 3,
    name: 'Outdated OpenSSL Version',
    severity: 'high',
    cvss: 8.1,
    cveBased: 'CVE-2023-4807',
    affectedServices: 2,
    discoveredDate: '2024-01-08',
    lastScanned: '2 hours ago',
  },
  {
    id: 4,
    name: 'Weak Password Requirements',
    severity: 'medium',
    cvss: 5.3,
    cveBased: 'CWE-521',
    affectedServices: 124,
    discoveredDate: '2024-01-05',
    lastScanned: '2 hours ago',
  },
  {
    id: 5,
    name: 'Default Credentials Detected',
    severity: 'high',
    cvss: 9.1,
    cveBased: 'CWE-798',
    affectedServices: 5,
    discoveredDate: '2024-01-02',
    lastScanned: '2 hours ago',
  },
]

const severityOptions = [
  { id: 'all', label: 'All Severities' },
  { id: 'critical', label: 'Critical Only', icon: <div className="w-2 h-2 rounded-full bg-critical" /> },
  { id: 'high', label: 'High Only', icon: <div className="w-2 h-2 rounded-full bg-high" /> },
  { id: 'medium', label: 'Medium Only', icon: <div className="w-2 h-2 rounded-full bg-medium" /> },
  { id: 'low', label: 'Low Only', icon: <div className="w-2 h-2 rounded-full bg-low" /> },
]

export default function VulnerabilitiesPage() {
  const [expandedId, setExpandedId] = useState<number | null>(null)
  const [filterSeverity, setFilterSeverity] = useState('all')

  const filteredVulnerabilities =
    filterSeverity === 'all'
      ? vulnerabilities
      : vulnerabilities.filter((v) => v.severity === filterSeverity)

  return (
    <AppLayout
      title="Vulnerabilities"
      subtitle="Manage and track all identified security vulnerabilities"
    >
      <div className="space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <div>
              <p className="text-sm text-muted-foreground">Total</p>
              <p className="text-3xl font-bold text-foreground">247</p>
            </div>
          </Card>
          <Card>
            <div>
              <p className="text-sm text-muted-foreground">Critical</p>
              <p className="text-3xl font-bold text-critical">12</p>
            </div>
          </Card>
          <Card>
            <div>
              <p className="text-sm text-muted-foreground">High</p>
              <p className="text-3xl font-bold text-high">34</p>
            </div>
          </Card>
          <Card>
            <div>
              <p className="text-sm text-muted-foreground">Medium</p>
              <p className="text-3xl font-bold text-medium">87</p>
            </div>
          </Card>
        </div>

        {/* Filter & Export */}
        <Card>
          <CardContent className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <Filter className="w-5 h-5 text-muted-foreground" />
              <SelectDropdown
                options={severityOptions}
                selected={filterSeverity}
                onSelect={setFilterSeverity}
                placeholder="Filter by severity"
                className="w-48"
              />
            </div>
            <Dropdown
              trigger={<Download className="w-4 h-4" />}
              items={[
                { id: 'pdf', label: 'PDF Report', icon: <Download size={16} /> },
                { id: 'csv', label: 'CSV Export', icon: <Download size={16} /> },
                { id: 'divider1', label: '', divider: true },
                { id: 'share', label: 'Share', icon: <Share2 size={16} /> },
              ]}
              align="right"
              triggerClassName="p-2 hover:bg-secondary"
            />
          </CardContent>
        </Card>

        {/* Vulnerabilities List */}
        <Card>
          <CustomScroll className="max-h-96">
            <div className="divide-y divide-border">
              {filteredVulnerabilities.map((vuln) => (
                <div key={vuln.id}>
                  <div
                    className="p-6 flex items-center justify-between cursor-pointer hover:bg-accent transition-colors"
                    onClick={() =>
                      setExpandedId(expandedId === vuln.id ? null : vuln.id)
                    }
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-foreground">{vuln.name}</h3>
                        <Badge severity={vuln.severity as any}>{vuln.severity}</Badge>
                        <span className="text-sm font-mono bg-muted px-2 py-1 rounded text-foreground">
                          CVSS {vuln.cvss}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>{vuln.cveBased}</span>
                        <span>{vuln.affectedServices} services affected</span>
                        <span>Discovered {vuln.discoveredDate}</span>
                      </div>
                    </div>
                    <ChevronDown
                      className={`w-5 h-5 text-muted-foreground transition-transform ${
                        expandedId === vuln.id ? 'rotate-180' : ''
                      }`}
                    />
                  </div>

                  {/* Expanded Details */}
                  {expandedId === vuln.id && (
                    <div className="px-6 py-4 bg-secondary border-t border-border space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-semibold text-foreground mb-1">Description</p>
                          <p className="text-sm text-muted-foreground">
                            This vulnerability allows attackers to {vuln.name.toLowerCase()} which could lead to unauthorized access or data exposure.
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-foreground mb-1">
                            Affected Items
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {vuln.affectedServices} services, last scanned {vuln.lastScanned}
                          </p>
                        </div>
                      </div>

                      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                        <p className="text-sm font-semibold text-red-900 mb-2">Recommended Fix</p>
                        <p className="text-sm text-red-800">
                          Update the affected service to the latest patched version and implement input validation and parameterized queries.
                        </p>
                      </div>

                      <div className="flex gap-2">
                        <WaymapButton variant="primary" size="sm">
                          Mark as Resolved
                        </WaymapButton>
                        <WaymapButton variant="outline" size="sm">
                          Add to Remediation Plan
                        </WaymapButton>
                        <WaymapButton variant="outline" size="sm">
                          View Details
                        </WaymapButton>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CustomScroll>
        </Card>
      </div>
    </AppLayout>
  )
}
