import { AppLayout } from '@/components/AppLayout'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card'
import { Badge } from '@/components/Badge'
import { WaymapButton } from '@/components/WaymapButton'
import { Alert } from '@/components/Alert'
import {
  ArrowLeft,
  Copy,
  Share2,
  ExternalLink,
  Code,
  AlertTriangle,
  CheckCircle2,
} from 'lucide-react'
import Link from 'next/link'

export default function VulnerabilityDetailPage({ params }: { params: { id: string } }) {
  return (
    <AppLayout
      title="SQL Injection in Login Form"
      subtitle="Detailed analysis and remediation guidance"
    >
      <div className="max-w-4xl space-y-6">
        {/* Back Button */}
        <Link href="/vulnerabilities" className="inline-flex items-center gap-2 text-primary hover:text-primary/80">
          <ArrowLeft className="w-4 h-4" />
          Back to Vulnerabilities
        </Link>

        {/* Header Card */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">
                  SQL Injection in Login Form
                </h2>
                <div className="flex items-center gap-4">
                  <Badge severity="critical">Critical</Badge>
                  <span className="font-mono text-sm bg-muted px-3 py-1 rounded text-foreground">
                    CVSS 9.8
                  </span>
                  <span className="text-sm text-muted-foreground">CVE-2024-1234</span>
                </div>
              </div>
              <div className="flex gap-2">
                <WaymapButton variant="outline" size="sm">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </WaymapButton>
                <WaymapButton variant="outline" size="sm">
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </WaymapButton>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4 pt-4 border-t border-border">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Severity</p>
                <p className="text-lg font-semibold text-critical">Critical</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">CVSS Score</p>
                <p className="text-lg font-semibold text-foreground">9.8</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Affected Services</p>
                <p className="text-lg font-semibold text-foreground">3</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Discovered</p>
                <p className="text-lg font-semibold text-foreground">2024-01-15</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Alert */}
        <Alert
          type="error"
          title="Critical Security Risk"
          message="This vulnerability allows unauthenticated attackers to execute arbitrary SQL queries, potentially leading to complete database compromise."
        />

        {/* Description */}
        <Card>
          <CardHeader>
            <CardTitle>Description</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-foreground">
              The application&apos;s login form is vulnerable to SQL injection attacks through the username field. 
              User input is not properly sanitized before being used in SQL queries, allowing attackers to bypass 
              authentication and potentially extract sensitive data from the database.
            </p>
            <div className="bg-secondary p-4 rounded-lg font-mono text-sm text-foreground">
              <p className="text-muted-foreground mb-2">Example Attack Payload:</p>
              <p>Username: admin&apos; OR &apos;1&apos;=&apos;1</p>
              <p>Password: anything</p>
            </div>
          </CardContent>
        </Card>

        {/* Technical Details */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Code className="w-5 h-5" />
              Technical Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="font-semibold text-foreground mb-2">Vulnerable Code Location:</p>
              <div className="bg-secondary p-4 rounded-lg font-mono text-sm text-foreground overflow-x-auto">
                <pre>{`// /src/auth/login.js - Line 45
const query = \`SELECT * FROM users WHERE username='${username}' AND password='${password}'\`;
db.query(query);`}</pre>
              </div>
            </div>

            <div>
              <p className="font-semibold text-foreground mb-2">Attack Vector:</p>
              <ul className="list-disc list-inside space-y-1 text-foreground">
                <li>Network accessible input form</li>
                <li>No input validation</li>
                <li>Unsanitized query construction</li>
                <li>Direct SQL execution</li>
              </ul>
            </div>

            <div>
              <p className="font-semibold text-foreground mb-2">Affected Endpoints:</p>
              <ul className="space-y-2">
                {[
                  { method: 'POST', endpoint: '/api/auth/login', service: 'API Server' },
                  { method: 'POST', endpoint: '/auth/login', service: 'Web App' },
                  { method: 'POST', endpoint: '/admin/login', service: 'Admin Portal' },
                ].map((ep, idx) => (
                  <li key={idx} className="flex items-center gap-3 text-sm">
                    <span className="font-mono bg-muted px-2 py-1 rounded text-xs">{ep.method}</span>
                    <span className="text-foreground">{ep.endpoint}</span>
                    <span className="text-muted-foreground">({ep.service})</span>
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Remediation */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-low" />
              Remediation Steps
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              {[
                {
                  step: 1,
                  title: 'Use Parameterized Queries',
                  desc: 'Replace dynamic query construction with prepared statements',
                  code: `const query = 'SELECT * FROM users WHERE username = ? AND password = ?';
db.query(query, [username, password]);`,
                },
                {
                  step: 2,
                  title: 'Input Validation',
                  desc: 'Implement strict validation on all user inputs',
                  code: `if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
  throw new Error('Invalid username format');
}`,
                },
                {
                  step: 3,
                  title: 'Use ORM Libraries',
                  desc: 'Consider using an ORM that handles escaping automatically',
                  code: `const user = await User.findOne({ 
  where: { username, password } 
});`,
                },
              ].map((item) => (
                <div key={item.step} className="border-l-4 border-primary pl-4">
                  <p className="font-semibold text-foreground mb-1">
                    Step {item.step}: {item.title}
                  </p>
                  <p className="text-sm text-muted-foreground mb-2">{item.desc}</p>
                  <div className="bg-secondary p-3 rounded font-mono text-sm text-foreground overflow-x-auto">
                    <pre>{item.code}</pre>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* References */}
        <Card>
          <CardHeader>
            <CardTitle>References & Resources</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {[
                { title: 'OWASP SQL Injection', url: '#' },
                { title: 'CWE-89: SQL Injection', url: '#' },
                { title: 'CVE-2024-1234 Details', url: '#' },
                { title: 'Secure Coding Guidelines', url: '#' },
              ].map((ref, idx) => (
                <a
                  key={idx}
                  href={ref.url}
                  className="flex items-center gap-2 p-2 hover:bg-accent rounded transition-colors text-primary"
                >
                  {ref.title}
                  <ExternalLink className="w-4 h-4" />
                </a>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex gap-4">
          <WaymapButton variant="primary" className="flex-1">
            Mark as Resolved
          </WaymapButton>
          <WaymapButton variant="outline" className="flex-1">
            Add to Remediation Plan
          </WaymapButton>
          <WaymapButton variant="outline" className="flex-1">
            Request Extensions
          </WaymapButton>
        </div>
      </div>
    </AppLayout>
  )
}
