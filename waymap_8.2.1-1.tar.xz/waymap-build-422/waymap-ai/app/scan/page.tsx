'use client'

import { useState } from 'react'
import { AppLayout } from '@/components/AppLayout'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card'
import { WaymapButton } from '@/components/WaymapButton'
import { Shield, AlertCircle, CheckCircle2 } from 'lucide-react'

export default function ScanPage() {
  const [scanning, setScanning] = useState(false)
  const [progress, setProgress] = useState(0)
  const [targetUrl, setTargetUrl] = useState('')

  const startScan = () => {
    setScanning(true)
    setProgress(0)

    // Simulate scanning progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setScanning(false)
          return 100
        }
        return prev + Math.random() * 30
      })
    }, 800)
  }

  return (
    <AppLayout title="Security Scan" subtitle="Launch a new security scan on your targets">
      <div className="max-w-2xl space-y-6">
        {/* Scan Input */}
        <Card>
          <CardHeader>
            <CardTitle>New Scan</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Target URL or IP Address
              </label>
              <input
                type="text"
                placeholder="https://example.com or 192.168.1.1"
                value={targetUrl}
                onChange={(e) => setTargetUrl(e.target.value)}
                className="w-full px-4 py-2 border border-border rounded-lg bg-input text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Scan Type
                </label>
                <select className="w-full px-4 py-2 border border-border rounded-lg bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary">
                  <option>Full Scan</option>
                  <option>Quick Scan</option>
                  <option>Custom</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Intensity
                </label>
                <select className="w-full px-4 py-2 border border-border rounded-lg bg-input text-foreground focus:outline-none focus:ring-2 focus:ring-primary">
                  <option>Normal</option>
                  <option>Light</option>
                  <option>Deep</option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2">
                <input type="checkbox" defaultChecked className="rounded" />
                <span className="text-sm text-foreground">Check for known vulnerabilities</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" defaultChecked className="rounded" />
                <span className="text-sm text-foreground">Scan SSL/TLS certificates</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" className="rounded" />
                <span className="text-sm text-foreground">Perform intrusive testing</span>
              </label>
            </div>

            <WaymapButton
              variant="primary"
              className="w-full"
              onClick={startScan}
              disabled={!targetUrl || scanning}
            >
              <Shield className="w-4 h-4 mr-2" />
              {scanning ? 'Scanning...' : 'Start Scan'}
            </WaymapButton>
          </CardContent>
        </Card>

        {/* Scan Progress */}
        {scanning && (
          <Card>
            <CardHeader>
              <CardTitle>Scan in Progress</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-foreground">Overall Progress</span>
                  <span className="text-muted-foreground">{Math.round(progress)}%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
              </div>

              <div className="space-y-3 mt-4">
                {[
                  { label: 'Host Discovery', progress: Math.min(progress, 20) },
                  { label: 'Port Scanning', progress: Math.max(0, Math.min(progress - 20, 20)) },
                  { label: 'Service Detection', progress: Math.max(0, Math.min(progress - 40, 20)) },
                  { label: 'Vulnerability Assessment', progress: Math.max(0, Math.min(progress - 60, 40)) },
                ].map((stage, idx) => (
                  <div key={idx}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-foreground">{stage.label}</span>
                      {stage.progress === stage.progress && stage.progress > 0 && (
                        <CheckCircle2 className="w-4 h-4 text-low" />
                      )}
                    </div>
                    <div className="h-1.5 bg-muted rounded-full">
                      <div
                        className="h-1.5 bg-primary rounded-full transition-all duration-300"
                        style={{ width: `${stage.progress}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {progress === 100 && (
          <Card className="border-2 border-low bg-green-50">
            <CardHeader>
              <CardTitle className="text-low">Scan Completed</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-foreground mb-4">
                Your scan has completed successfully. View the detailed report to see the findings.
              </p>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="bg-white rounded-lg p-3">
                  <p className="text-xs text-muted-foreground">Critical Issues</p>
                  <p className="text-2xl font-bold text-critical">3</p>
                </div>
                <div className="bg-white rounded-lg p-3">
                  <p className="text-xs text-muted-foreground">High Issues</p>
                  <p className="text-2xl font-bold text-high">12</p>
                </div>
                <div className="bg-white rounded-lg p-3">
                  <p className="text-xs text-muted-foreground">Medium Issues</p>
                  <p className="text-2xl font-bold text-medium">28</p>
                </div>
              </div>
              <WaymapButton variant="primary" className="w-full">
                View Full Report
              </WaymapButton>
            </CardContent>
          </Card>
        )}

        {/* Recent Scans */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Scans</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { url: 'example.com', date: '2 days ago', findings: 8, status: 'Complete' },
                { url: 'api.example.com', date: '5 days ago', findings: 3, status: 'Complete' },
                { url: '192.168.1.1', date: '1 week ago', findings: 15, status: 'Complete' },
              ].map((scan, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 bg-secondary rounded-lg"
                >
                  <div>
                    <p className="font-medium text-foreground">{scan.url}</p>
                    <p className="text-sm text-muted-foreground">{scan.date}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-foreground">{scan.findings} findings</p>
                    <p className="text-xs text-low">{scan.status}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  )
}
