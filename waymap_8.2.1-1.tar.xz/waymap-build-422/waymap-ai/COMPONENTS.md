# Waymap Desktop - Custom Components

## Overview

Waymap Desktop includes custom-built dropdown menus and scrollers designed to match the pastel design system and provide enhanced user experience for security scanning applications.

## Components

### Dropdown (`components/Dropdown.tsx`)

A flexible, reusable dropdown menu component with support for icons, dividers, and disabled states.

#### Features
- **Trigger-based opening**: Click trigger to toggle dropdown menu
- **Icons support**: Display icons next to menu items
- **Dividers**: Visual separation between menu item groups
- **Disabled states**: Disable specific menu items
- **Click outside detection**: Auto-closes when clicking outside
- **Alignment options**: Left or right alignment
- **Smooth animations**: Transitions with hover effects

#### Usage

```tsx
import { Dropdown } from '@/components/Dropdown'
import { Download, Share2 } from 'lucide-react'

<Dropdown
  trigger={<>Actions</>}
  items={[
    { id: 'download', label: 'Download', icon: <Download size={16} /> },
    { id: 'share', label: 'Share', icon: <Share2 size={16} /> },
    { id: 'divider', label: '', divider: true },
    { id: 'delete', label: 'Delete', icon: <Trash2 size={16} /> },
  ]}
  align="left"
  onClick={(item) => console.log(item.id)}
/>
```

#### Props

```typescript
interface DropdownItem {
  id: string
  label: string
  icon?: React.ReactNode
  disabled?: boolean
  divider?: boolean
  onClick?: () => void
}

interface DropdownProps {
  trigger: React.ReactNode
  items: DropdownItem[]
  align?: 'left' | 'right'
  className?: string
  triggerClassName?: string
  menuClassName?: string
}
```

---

### SelectDropdown (`components/Dropdown.tsx`)

A form-friendly select component styled as a searchable dropdown with better UX than native selects.

#### Features
- **Label support**: Optional label above the input
- **Error states**: Display validation errors
- **Placeholder text**: Customize placeholder text
- **Icon support**: Icons beside each option
- **Selected indicator**: Highlights selected option with primary color
- **Accessible**: Keyboard navigation support
- **Max height**: Scrollable overflow for long lists

#### Usage

```tsx
import { SelectDropdown } from '@/components/Dropdown'

const [selected, setSelected] = useState<string>('')

<SelectDropdown
  label="Filter by Severity"
  options={[
    { id: 'critical', label: 'Critical', icon: <AlertIcon /> },
    { id: 'high', label: 'High', icon: <AlertIcon /> },
    { id: 'medium', label: 'Medium', icon: <AlertIcon /> },
  ]}
  selected={selected}
  onSelect={setSelected}
  placeholder="Choose severity level"
  error={selected === '' ? 'This field is required' : ''}
/>
```

#### Props

```typescript
interface SelectDropdownProps {
  label?: string
  options: DropdownItem[]
  selected?: string
  onSelect: (id: string) => void
  placeholder?: string
  error?: string
  className?: string
}
```

---

### Scroller (`components/Scroller.tsx`)

A horizontal or vertical scrollable container with smooth navigation buttons that appear on hover.

#### Features
- **Dual orientation**: Horizontal or vertical scrolling
- **Auto-hiding buttons**: Scroll buttons only appear on hover
- **Smooth scrolling**: CSS-based smooth scroll behavior
- **Smart button visibility**: Buttons hide when at scroll edges
- **Customizable scroll distance**: Adjust pixels scrolled per click
- **Gradient overlays**: Buttons have gradient backgrounds

#### Usage

```tsx
import { Scroller } from '@/components/Scroller'

<Scroller 
  orientation="horizontal" 
  scrollAmount={300}
  showScrollButtons={true}
>
  {/* Card items to scroll */}
  <div className="flex-shrink-0 w-48">Card 1</div>
  <div className="flex-shrink-0 w-48">Card 2</div>
</Scroller>
```

#### Props

```typescript
interface ScrollerProps {
  children: React.ReactNode
  className?: string
  showScrollButtons?: boolean
  scrollAmount?: number
  orientation?: 'horizontal' | 'vertical'
}
```

---

### CustomScroll (`components/Scroller.tsx`)

Styled scrollbar component with custom styling that matches the Waymap design system.

#### Features
- **Custom scrollbar styling**: Purple-tinted scrollbar
- **Hover effects**: Darker color on hover
- **Thin design**: Minimal visual footprint
- **Cross-browser**: Works with -webkit and standard scrollbar-width
- **Smooth scroll**: CSS smooth scrolling behavior

#### Usage

```tsx
import { CustomScroll } from '@/components/Scroller'

<CustomScroll className="h-96 border rounded-lg">
  {/* Long list of items */}
  <div className="space-y-2">
    {items.map(item => (
      <div key={item.id} className="p-3">
        {item.name}
      </div>
    ))}
  </div>
</CustomScroll>
```

#### Props

```typescript
interface CustomScrollProps {
  children: React.ReactNode
  className?: string
}
```

---

### VirtualScrollList (`components/Scroller.tsx`)

Performance-optimized virtual scroll component for rendering large lists efficiently.

#### Features
- **Virtual rendering**: Only renders visible items
- **Performance**: Handles 1000+ items smoothly
- **Fixed height**: Requires fixed item height for calculations
- **Offset calculation**: Automatic spacer management
- **Memory efficient**: Minimal DOM nodes

#### Usage

```tsx
import { VirtualScrollList } from '@/components/Scroller'

const items = Array.from({ length: 10000 }, (_, i) => ({
  id: i,
  title: `Item ${i}`,
}))

<VirtualScrollList
  items={items}
  itemHeight={56}
  containerHeight={400}
  renderItem={(item, index) => (
    <div className="p-3">{item.title}</div>
  )}
/>
```

#### Props

```typescript
interface VirtualScrollListProps<T> {
  items: T[]
  itemHeight: number
  renderItem: (item: T, index: number) => React.ReactNode
  containerHeight: number
  className?: string
}
```

---

## Design System Integration

All components use the Waymap design system colors:

- **Primary**: `#8b7db8` (Purple) - for selected/highlighted states
- **Background**: `#fafaf8` (Off-white) - container backgrounds
- **Border**: `#e0e0e0` (Light gray) - dividers and borders
- **Muted**: `#e8e8e8` (Very light gray) - disabled states
- **Severity colors**:
  - Critical: `#d32f2f` (Red)
  - High: `#f57c00` (Orange)
  - Medium: `#fbc02d` (Yellow)
  - Low: `#689f38` (Green)

---

## Usage Examples

### Dashboard with Filters

```tsx
import { SelectDropdown } from '@/components/Dropdown'
import { CustomScroll } from '@/components/Scroller'

export function Dashboard() {
  const [filterSeverity, setFilterSeverity] = useState('all')
  
  return (
    <div className="space-y-4">
      <SelectDropdown
        label="Filter by Severity"
        options={severityOptions}
        selected={filterSeverity}
        onSelect={setFilterSeverity}
      />
      
      <CustomScroll className="h-96">
        {/* Filtered list of vulnerabilities */}
      </CustomScroll>
    </div>
  )
}
```

### Horizontal Card Carousel

```tsx
import { Scroller } from '@/components/Scroller'

export function CardCarousel() {
  return (
    <Scroller orientation="horizontal" scrollAmount={300}>
      {cards.map(card => (
        <div key={card.id} className="flex-shrink-0 w-48">
          <Card>{card.title}</Card>
        </div>
      ))}
    </Scroller>
  )
}
```

### Large Data Table

```tsx
import { VirtualScrollList } from '@/components/Scroller'

export function LargeTable() {
  return (
    <VirtualScrollList
      items={data}
      itemHeight={64}
      containerHeight={600}
      renderItem={(row, index) => (
        <TableRow key={row.id} data={row} />
      )}
    />
  )
}
```

---

## Accessibility

- **Keyboard navigation**: Dropdowns close with Escape key
- **ARIA labels**: Scroll buttons have aria-label attributes
- **Focus management**: Click outside detection for accessibility
- **Screen readers**: Semantic HTML with proper roles

---

## Demo Page

View all components in action at `/components-demo`

This page showcases:
- Dropdown menus with various configurations
- Select dropdowns with severity filtering
- Horizontal and vertical scrollers
- Custom scrollbar styling
- Virtual scroll performance
- Real-world integration examples

---

## Performance Considerations

- **Dropdown**: O(n) for menu rendering, negligible for <100 items
- **CustomScroll**: No performance impact, pure CSS
- **VirtualScrollList**: O(1) DOM nodes regardless of data size
- **Scroller**: Smooth 60fps scrolling with CSS transitions

---

## Browser Support

- Chrome/Edge: Full support
- Firefox: Full support (with scrollbar-width property)
- Safari: Full support (with -webkit prefix)
- IE: Not supported
