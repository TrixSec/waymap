'use client'

import React, { useRef, useEffect, useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'

interface ScrollerProps {
  children: React.ReactNode
  className?: string
  showScrollButtons?: boolean
  scrollAmount?: number
  orientation?: 'horizontal' | 'vertical'
}

export function Scroller({
  children,
  className = '',
  showScrollButtons = true,
  scrollAmount = 300,
  orientation = 'horizontal',
}: ScrollerProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [canScrollLeft, setCanScrollLeft] = useState(false)
  const [canScrollRight, setCanScrollRight] = useState(true)
  const [canScrollUp, setCanScrollUp] = useState(false)
  const [canScrollDown, setCanScrollDown] = useState(true)

  const checkScroll = () => {
    if (!containerRef.current) return

    if (orientation === 'horizontal') {
      setCanScrollLeft(containerRef.current.scrollLeft > 0)
      setCanScrollRight(
        containerRef.current.scrollLeft <
          containerRef.current.scrollWidth - containerRef.current.clientWidth - 10
      )
    } else {
      setCanScrollUp(containerRef.current.scrollTop > 0)
      setCanScrollDown(
        containerRef.current.scrollTop <
          containerRef.current.scrollHeight - containerRef.current.clientHeight - 10
      )
    }
  }

  useEffect(() => {
    checkScroll()
    const container = containerRef.current
    if (container) {
      container.addEventListener('scroll', checkScroll)
      window.addEventListener('resize', checkScroll)
      return () => {
        container.removeEventListener('scroll', checkScroll)
        window.removeEventListener('resize', checkScroll)
      }
    }
  }, [orientation])

  const scroll = (direction: 'left' | 'right' | 'up' | 'down') => {
    if (!containerRef.current) return

    const isHorizontal = orientation === 'horizontal'
    const scrollProperty = isHorizontal ? 'scrollLeft' : 'scrollTop'
    const multiplier = ['right', 'down'].includes(direction) ? 1 : -1

    containerRef.current.scrollBy({
      [isHorizontal ? 'left' : 'top']: scrollAmount * multiplier,
      behavior: 'smooth',
    })
  }

  if (orientation === 'horizontal') {
    return (
      <div className={`relative group ${className}`}>
        {showScrollButtons && canScrollLeft && (
          <button
            onClick={() => scroll('left')}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-gradient-to-r from-background via-background to-transparent p-2 rounded-r-lg text-muted-foreground hover:text-foreground transition-colors opacity-0 group-hover:opacity-100 duration-200"
            aria-label="Scroll left"
          >
            <ChevronLeft size={20} />
          </button>
        )}

        <div
          ref={containerRef}
          className="overflow-x-auto overflow-y-hidden"
          style={{
            scrollBehavior: 'smooth',
          }}
        >
          <div className="flex gap-4 pb-2">{children}</div>
        </div>

        {showScrollButtons && canScrollRight && (
          <button
            onClick={() => scroll('right')}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-gradient-to-l from-background via-background to-transparent p-2 rounded-l-lg text-muted-foreground hover:text-foreground transition-colors opacity-0 group-hover:opacity-100 duration-200"
            aria-label="Scroll right"
          >
            <ChevronRight size={20} />
          </button>
        )}
      </div>
    )
  }

  // Vertical scroller
  return (
    <div className={`relative group flex flex-col ${className}`}>
      {showScrollButtons && canScrollUp && (
        <button
          onClick={() => scroll('up')}
          className="absolute -top-8 left-1/2 -translate-x-1/2 z-10 bg-gradient-to-b from-background via-background to-transparent p-2 rounded-b-lg text-muted-foreground hover:text-foreground transition-colors opacity-0 group-hover:opacity-100 duration-200"
          aria-label="Scroll up"
        >
          <ChevronLeft size={20} className="rotate-90" />
        </button>
      )}

      <div
        ref={containerRef}
        className="overflow-y-auto overflow-x-hidden"
        style={{
          scrollBehavior: 'smooth',
        }}
      >
        <div className="flex flex-col gap-2">{children}</div>
      </div>

      {showScrollButtons && canScrollDown && (
        <button
          onClick={() => scroll('down')}
          className="absolute -bottom-8 left-1/2 -translate-x-1/2 z-10 bg-gradient-to-t from-background via-background to-transparent p-2 rounded-t-lg text-muted-foreground hover:text-foreground transition-colors opacity-0 group-hover:opacity-100 duration-200"
          aria-label="Scroll down"
        >
          <ChevronRight size={20} className="-rotate-90" />
        </button>
      )}
    </div>
  )
}

interface CustomScrollProps {
  children: React.ReactNode
  className?: string
}

export function CustomScroll({ children, className = '' }: CustomScrollProps) {
  return (
    <div
      className={`overflow-auto ${className}`}
      style={{
        scrollbarWidth: 'thin',
        scrollbarColor: 'rgba(139, 125, 184, 0.5) transparent',
      }}
    >
      <style>{`
        ::-webkit-scrollbar {
          width: 8px;
          height: 8px;
        }
        ::-webkit-scrollbar-track {
          background: transparent;
        }
        ::-webkit-scrollbar-thumb {
          background: rgba(139, 125, 184, 0.5);
          border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: rgba(139, 125, 184, 0.7);
        }
      `}</style>
      {children}
    </div>
  )
}

interface VirtualScrollListProps<T> {
  items: T[]
  itemHeight: number
  renderItem: (item: T, index: number) => React.ReactNode
  containerHeight: number
  className?: string
}

export function VirtualScrollList<T>({
  items,
  itemHeight,
  renderItem,
  containerHeight,
  className = '',
}: VirtualScrollListProps<T>) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [scrollTop, setScrollTop] = useState(0)

  const startIndex = Math.floor(scrollTop / itemHeight)
  const endIndex = Math.ceil((scrollTop + containerHeight) / itemHeight)
  const visibleItems = items.slice(startIndex, Math.min(endIndex + 1, items.length))
  const offsetY = startIndex * itemHeight

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    setScrollTop((e.target as HTMLDivElement).scrollTop)
  }

  return (
    <div
      ref={containerRef}
      onScroll={handleScroll}
      className={`overflow-y-auto ${className}`}
      style={{ height: containerHeight }}
    >
      {/* Spacer for items above visible area */}
      {startIndex > 0 && (
        <div style={{ height: offsetY }} />
      )}

      {/* Visible items */}
      <div>
        {visibleItems.map((item, index) => (
          <div key={startIndex + index} style={{ height: itemHeight }}>
            {renderItem(item, startIndex + index)}
          </div>
        ))}
      </div>

      {/* Spacer for items below visible area */}
      {endIndex < items.length && (
        <div style={{ height: (items.length - endIndex) * itemHeight }} />
      )}
    </div>
  )
}
