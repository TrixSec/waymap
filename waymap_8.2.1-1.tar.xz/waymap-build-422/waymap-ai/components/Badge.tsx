import React from 'react'

type SeverityLevel = 'critical' | 'high' | 'medium' | 'low' | 'info'

interface BadgeProps {
  severity: SeverityLevel
  children: React.ReactNode
  className?: string
}

const severityConfig: Record<SeverityLevel, { bg: string; text: string; border: string }> = {
  critical: {
    bg: 'bg-red-50',
    text: 'text-red-900',
    border: 'border-red-200',
  },
  high: {
    bg: 'bg-orange-50',
    text: 'text-orange-900',
    border: 'border-orange-200',
  },
  medium: {
    bg: 'bg-amber-50',
    text: 'text-amber-900',
    border: 'border-amber-200',
  },
  low: {
    bg: 'bg-green-50',
    text: 'text-green-900',
    border: 'border-green-200',
  },
  info: {
    bg: 'bg-blue-50',
    text: 'text-blue-900',
    border: 'border-blue-200',
  },
}

export function Badge({ severity, children, className = '' }: BadgeProps) {
  const config = severityConfig[severity]
  return (
    <span
      className={`inline-flex items-center rounded-full px-3 py-1 text-sm font-medium border ${config.bg} ${config.text} ${config.border} ${className}`}
    >
      {children}
    </span>
  )
}
