import React from 'react'

interface StatCardProps {
  label: string
  value: string | number
  change?: string
  changeType?: 'positive' | 'negative' | 'neutral'
  icon?: React.ReactNode
  className?: string
}

export function StatCard({
  label,
  value,
  change,
  changeType = 'neutral',
  icon,
  className = '',
}: StatCardProps) {
  const changeColor =
    changeType === 'positive'
      ? 'text-low'
      : changeType === 'negative'
        ? 'text-critical'
        : 'text-muted-foreground'

  return (
    <div className={`bg-card rounded-lg border border-border p-6 ${className}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground mb-1">{label}</p>
          <p className="text-3xl font-bold text-foreground">{value}</p>
          {change && (
            <p className={`text-xs ${changeColor} mt-2`}>{change}</p>
          )}
        </div>
        {icon && (
          <div className="w-12 h-12 flex items-center justify-center">
            {icon}
          </div>
        )}
      </div>
    </div>
  )
}
