'use client'

import React, { useState, useRef, useEffect } from 'react'
import { ChevronDown } from 'lucide-react'

export interface DropdownItem {
  id: string
  label: string
  icon?: React.ReactNode
  disabled?: boolean
  divider?: boolean
  onClick?: () => void
}

interface DropdownProps {
  trigger: React.ReactNode
  items: DropdownItem[]
  align?: 'left' | 'right'
  className?: string
  triggerClassName?: string
  menuClassName?: string
}

export function Dropdown({
  trigger,
  items,
  align = 'left',
  className = '',
  triggerClassName = '',
  menuClassName = '',
}: DropdownProps) {
  const [isOpen, setIsOpen] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const menuRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false)
      }
    }

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside)
      return () => {
        document.removeEventListener('mousedown', handleClickOutside)
      }
    }
  }, [isOpen])

  const handleItemClick = (item: DropdownItem) => {
    if (!item.disabled && !item.divider) {
      item.onClick?.()
      setIsOpen(false)
    }
  }

  return (
    <div ref={containerRef} className={`relative inline-block ${className}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-2 px-4 py-2 bg-card border border-border rounded-lg hover:bg-secondary text-foreground transition-colors ${triggerClassName}`}
      >
        {trigger}
      </button>

      {isOpen && (
        <div
          ref={menuRef}
          className={`absolute top-full mt-2 ${
            align === 'right' ? 'right-0' : 'left-0'
          } bg-card border border-border rounded-lg shadow-lg z-50 min-w-48 overflow-hidden ${menuClassName}`}
        >
          <div className="py-1">
            {items.map((item, index) => (
              <div key={item.id}>
                {item.divider ? (
                  <div className="h-px bg-border my-1" />
                ) : (
                  <button
                    onClick={() => handleItemClick(item)}
                    disabled={item.disabled}
                    className={`w-full px-4 py-2 text-left text-sm flex items-center gap-3 transition-colors ${
                      item.disabled
                        ? 'text-muted-foreground cursor-not-allowed'
                        : 'text-foreground hover:bg-secondary'
                    }`}
                  >
                    {item.icon && <span className="flex-shrink-0">{item.icon}</span>}
                    <span>{item.label}</span>
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

interface SelectDropdownProps {
  label?: string
  options: DropdownItem[]
  selected?: string
  onSelect: (id: string) => void
  placeholder?: string
  error?: string
  className?: string
}

export function SelectDropdown({
  label,
  options,
  selected,
  onSelect,
  placeholder = 'Select an option',
  error,
  className = '',
}: SelectDropdownProps) {
  const [isOpen, setIsOpen] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const selectedLabel = options.find((opt) => opt.id === selected)?.label || placeholder

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false)
      }
    }

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside)
      return () => {
        document.removeEventListener('mousedown', handleClickOutside)
      }
    }
  }, [isOpen])

  return (
    <div className={className}>
      {label && (
        <label className="block text-sm font-medium text-foreground mb-2">
          {label}
        </label>
      )}
      <div ref={containerRef} className="relative">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`w-full px-4 py-2 bg-input border rounded-lg text-foreground text-left flex items-center justify-between hover:bg-secondary transition-colors focus:outline-none focus:ring-2 focus:ring-primary ${
            error ? 'border-critical' : 'border-border'
          }`}
        >
          <span className={selected ? 'text-foreground' : 'text-muted-foreground'}>
            {selectedLabel}
          </span>
          <ChevronDown
            size={20}
            className={`transition-transform ${isOpen ? 'rotate-180' : ''}`}
          />
        </button>

        {isOpen && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-card border border-border rounded-lg shadow-lg z-50 overflow-hidden">
            <div className="py-1 max-h-60 overflow-y-auto">
              {options.map((option) => (
                <button
                  key={option.id}
                  onClick={() => {
                    onSelect(option.id)
                    setIsOpen(false)
                  }}
                  disabled={option.disabled}
                  className={`w-full px-4 py-2 text-left text-sm flex items-center gap-3 transition-colors ${
                    selected === option.id
                      ? 'bg-primary text-primary-foreground'
                      : option.disabled
                        ? 'text-muted-foreground cursor-not-allowed'
                        : 'text-foreground hover:bg-secondary'
                  }`}
                >
                  {option.icon && <span className="flex-shrink-0">{option.icon}</span>}
                  <span>{option.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
      {error && <p className="text-sm text-critical mt-1">{error}</p>}
    </div>
  )
}
