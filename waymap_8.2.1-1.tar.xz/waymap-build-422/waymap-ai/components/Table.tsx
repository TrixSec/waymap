import React from 'react'

interface TableProps {
  children: React.ReactNode
  className?: string
}

export function Table({ children, className = '' }: TableProps) {
  return (
    <div className={`overflow-x-auto border border-border rounded-lg ${className}`}>
      <table className="w-full text-sm">{children}</table>
    </div>
  )
}

export function TableHeader({ children, className = '' }: TableProps) {
  return (
    <thead className={`bg-secondary border-b border-border ${className}`}>
      <tr>{children}</tr>
    </thead>
  )
}

export function TableBody({ children, className = '' }: TableProps) {
  return <tbody className={className}>{children}</tbody>
}

interface TableRowProps {
  children: React.ReactNode
  className?: string
  onClick?: () => void
}

export function TableRow({ children, className = '', onClick }: TableRowProps) {
  return (
    <tr
      className={`border-b border-border hover:bg-accent transition-colors ${onClick ? 'cursor-pointer' : ''} ${className}`}
      onClick={onClick}
    >
      {children}
    </tr>
  )
}

interface TableCellProps {
  children: React.ReactNode
  className?: string
  header?: boolean
}

export function TableCell({ children, className = '', header = false }: TableCellProps) {
  const Component = header ? 'th' : 'td'
  return (
    <Component
      className={`px-6 py-4 text-left ${header ? 'font-semibold text-foreground' : 'text-foreground'} ${className}`}
    >
      {children}
    </Component>
  )
}
