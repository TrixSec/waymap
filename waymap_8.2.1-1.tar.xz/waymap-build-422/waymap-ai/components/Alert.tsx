import React, { ReactNode } from 'react'
import { AlertTriangle, AlertCircle, CheckCircle2, Info } from 'lucide-react'

type AlertType = 'error' | 'warning' | 'success' | 'info'

interface AlertProps {
  type: AlertType
  title: string
  message: string
  className?: string
}

const typeConfig: Record<
  AlertType,
  { bg: string; border: string; icon: React.ReactNode; textColor: string }
> = {
  error: {
    bg: 'bg-red-50',
    border: 'border-red-200',
    icon: <AlertTriangle className="w-5 h-5 text-red-600" />,
    textColor: 'text-red-900',
  },
  warning: {
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    icon: <AlertCircle className="w-5 h-5 text-amber-600" />,
    textColor: 'text-amber-900',
  },
  success: {
    bg: 'bg-green-50',
    border: 'border-green-200',
    icon: <CheckCircle2 className="w-5 h-5 text-green-600" />,
    textColor: 'text-green-900',
  },
  info: {
    bg: 'bg-blue-50',
    border: 'border-blue-200',
    icon: <Info className="w-5 h-5 text-blue-600" />,
    textColor: 'text-blue-900',
  },
}

export function Alert({ type, title, message, className = '' }: AlertProps) {
  const config = typeConfig[type]

  return (
    <div
      className={`flex gap-3 p-4 rounded-lg border ${config.bg} ${config.border} ${className}`}
    >
      {config.icon}
      <div className="flex-1">
        <h4 className={`font-semibold ${config.textColor}`}>{title}</h4>
        <p className={`text-sm ${config.textColor} opacity-90`}>{message}</p>
      </div>
    </div>
  )
}
