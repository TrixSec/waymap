import React from 'react'
import { Sidebar } from './Sidebar'
import { Header } from './Header'

interface AppLayoutProps {
  children: React.ReactNode
  title?: string
  subtitle?: string
}

export function AppLayout({ children, title, subtitle }: AppLayoutProps) {
  return (
    <div className="flex flex-col">
      <Sidebar />
      <Header title={title} subtitle={subtitle} />
      <main className="ml-64 flex-1 p-6">{children}</main>
    </div>
  )
}
